task :ruby_env do
    FOO = 47
end
