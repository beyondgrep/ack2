#!/usr/bin/perl

use constant NAME => 'Foo';
