
#define FOO 1
#define BAR 2
